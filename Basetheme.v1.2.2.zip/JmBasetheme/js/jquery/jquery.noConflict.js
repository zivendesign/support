/*! jQuery noConflict */
var ja = $j = $JM = jQuery.noConflict();